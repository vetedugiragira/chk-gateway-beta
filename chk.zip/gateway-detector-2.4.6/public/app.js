(() => {
  'use strict';

  const gateways = [
    ['stripe', 'Stripe'], ['asaas', 'Asaas'], ['nuuvem', 'Nuuvem (plataforma)'],
    ['mercadopago', 'Mercado Pago'], ['pagbank', 'PagBank/PagSeguro'], ['paypal', 'PayPal'],
    ['adyen', 'Adyen'], ['pagarme', 'Pagar.me'], ['iugu', 'Iugu'], ['ebanx', 'EBANX'],
    ['cielo', 'Cielo'], ['getnet', 'Getnet'], ['rede', 'Rede'], ['qualquer', 'Qualquer gateway']
  ];
  const niches = [
    ['qualquer', 'Qualquer nicho'], ['joias', 'Joias'], ['roupas', 'Roupas'], ['calcados', 'Calçados'],
    ['eletronicos', 'Eletrônicos'], ['moveis', 'Móveis'], ['beleza', 'Beleza'], ['casa', 'Casa'],
    ['esportes', 'Esportes'], ['alimentos', 'Alimentos'], ['livros', 'Livros'], ['pet', 'Pet']
  ];
  const countries = [
    ['BR', 'Brasil'], ['US', 'Estados Unidos'], ['PT', 'Portugal'], ['MX', 'México'],
    ['AR', 'Argentina'], ['CO', 'Colômbia'], ['CL', 'Chile']
  ];

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));

  function esc(value) {
    return String(value ?? '').replace(/[&<>'"]/g, (ch) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[ch]));
  }

  function fillSelect(selector, items) {
    const el = $(selector);
    if (!el) return;
    el.replaceChildren(...items.map(([value, label]) => {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = label;
      return option;
    }));
  }

  function showOutput(html, cls = '') {
    const output = $('#output');
    if (!output) return;
    output.className = `card ${cls}`.trim();
    output.innerHTML = html;
    output.hidden = false;
    output.style.display = 'block';
    output.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function setBusy(button, busy, idleLabel, busyLabel) {
    if (!button) return;
    button.disabled = busy;
    button.textContent = busy ? busyLabel : idleLabel;
  }

  function gatewayChips(gatewaysFound, targetId) {
    if (!Array.isArray(gatewaysFound) || gatewaysFound.length === 0) {
      return '<div class="muted">Nenhum fingerprint técnico suficiente.</div>';
    }
    const wrapper = document.createElement('div');
    wrapper.className = 'chips';
    for (const gateway of gatewaysFound) {
      const chip = document.createElement('span');
      chip.className = `chip ${targetId && gateway.id === targetId ? 'good' : ''}`.trim();
      chip.textContent = `${gateway.name} · ${gateway.score}% · ${gateway.confidence}`;
      wrapper.appendChild(chip);
    }
    return wrapper.outerHTML;
  }

  function collectOptions() {
    return {
      gateway: $('#gateway')?.value || 'qualquer',
      niche: $('#niche')?.value || 'qualquer',
      country: $('#country')?.value || 'BR',
      count: Number($('#count')?.value || 20),
      custom: $('#custom')?.value.trim() || ''
    };
  }

  async function safeJson(response) {
    const text = await response.text();
    try {
      return JSON.parse(text);
    } catch {
      return { ok: false, error: `Resposta inválida do servidor (HTTP ${response.status}).` };
    }
  }

  function activatePanel(name, updateHash = true) {
    const valid = ['discover', 'scan', 'all'];
    const active = valid.includes(name) ? name : 'discover';
    $$('.tab').forEach((button) => {
      const isActive = button.dataset.panel === active;
      button.classList.toggle('active', isActive);
      button.setAttribute('aria-selected', String(isActive));
    });
    ['discover', 'scan'].forEach((id) => {
      const panel = $(`#${id}`);
      if (!panel) return;
      panel.hidden = !(active === 'all' || active === id);
      panel.classList.toggle('hidden-by-tab', panel.hidden);
    });
    if (updateHash) {
      try {
        history.replaceState(null, '', active === 'discover' ? '#discover' : `#${active}`);
      } catch (_) {}
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function scanUrl() {
    const url = $('#url')?.value.trim();
    if (!url) {
      showOutput('<b>Informe uma URL.</b>', 'error');
      return;
    }
    const button = $('#scanBtn');
    setBusy(button, true, 'Analisar URL', 'Analisando...');
    try {
      const response = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data = await safeJson(response);
      if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
      const evidence = Array.isArray(data.gateways) ? data.gateways.flatMap((g) => g.evidence || []).slice(0, 12) : [];
      showOutput(
        `<div class="row"><h2>Resultado da análise</h2><span class="chip">HTTP ${esc(data.status)}</span></div>` +
        `<p><a href="${esc(data.url)}" target="_blank" rel="noreferrer">${esc(data.url)}</a></p>` +
        `<div class="metric">E-commerce: ${esc(data.ecommerceScore)}%</div>` +
        gatewayChips(data.gateways) +
        `<div class="metric">Evidências técnicas: ${esc(evidence.join(', ') || 'nenhuma')}</div>`,
        'success'
      );
    } catch (error) {
      showOutput(`<b>Erro:</b> ${esc(error.message)}`, 'error');
    } finally {
      setBusy(button, false, 'Analisar URL', 'Analisando...');
    }
  }

  async function showQueries() {
    const button = $('#queryBtn');
    setBusy(button, true, 'Ver consultas', 'Montando...');
    try {
      const params = new URLSearchParams(collectOptions());
      const response = await fetch(`/api/discover-query?${params.toString()}`);
      const data = await safeJson(response);
      if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
      const box = $('#queryBox');
      const text = $('#queryText');
      if (box && text) {
        text.innerHTML = Array.isArray(data.queries)
          ? data.queries.map((query, index) => `${index + 1}. ${esc(query)}`).join('<br>')
          : 'Nenhuma consulta gerada.';
        box.hidden = false;
        box.style.display = 'block';
      }
    } catch (error) {
      showOutput(`<b>Erro:</b> ${esc(error.message)}`, 'error');
    } finally {
      setBusy(button, false, 'Ver consultas', 'Montando...');
    }
  }

  async function testProvider() {
    const button = $('#testBtn');
    setBusy(button, true, 'Testar conexão', 'Testando...');
    try {
      const response = await fetch('/api/provider-test', { method: 'POST' });
      const data = await safeJson(response);
      if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
      showOutput('<b>Conexão com o Serper funcionando.</b><p class="note">A chave foi aceita pelo teste de busca.</p>', 'success');
    } catch (error) {
      showOutput(`<b>Teste do Serper:</b> ${esc(error.message)}<p class="note">A chave não é exibida. Depois de corrigir o .env, reinicie o servidor com <span class="mono">npm start</span>.</p>`, 'error');
    } finally {
      setBusy(button, false, 'Testar conexão', 'Testando...');
    }
  }

  function renderStats(data) {
    return `<div class="stats">` +
      `<span class="stat"><b>${esc(data.requested)}</b> solicitados</span>` +
      `<span class="stat"><b>${esc(data.candidates)}</b> candidatos</span>` +
      `<span class="stat"><b>${esc(data.analyzed)}</b> verificados</span>` +
      `<span class="stat"><b>${esc(data.accepted)}</b> confirmados</span>` +
      `<span class="stat"><b>${esc(data.rejected)}</b> descartados</span>` +
      `</div>`;
  }

  function renderResultCard(item, index) {
    const gatewaysFound = item.detectedGateways || [];
    const target = item.targetGateway && item.targetGateway !== 'Qualquer gateway'
      ? gatewaysFound.find((gateway) => gateway.name === item.targetGateway)?.id
      : null;
    return `<article class="result">` +
      `<div class="row"><h3>#${index + 1} ${esc(item.title)}</h3><span class="chip good">Score ${esc(item.totalScore)}</span></div>` +
      `<a href="${esc(item.url)}" target="_blank" rel="noreferrer">${esc(item.url)}</a>` +
      `<p class="note">${esc(item.description)}</p>` +
      gatewayChips(gatewaysFound, target) +
      `<div class="metric">Nicho: ${esc(item.nicheVerified?.score ?? 0)}% · E-commerce: ${esc(item.ecommerceScore ?? 0)}% · HTTP: ${esc(item.verification?.status ?? '—')}</div>` +
      `<div class="metric">Evidências: ${esc(gatewaysFound.flatMap((g) => g.evidence || []).slice(0, 6).join(', ') || 'nenhuma')}</div>` +
      `</article>`;
  }

  async function discoverSites() {
    const button = $('#discoverBtn');
    setBusy(button, true, 'Pesquisar e analisar automaticamente', 'Pesquisando e verificando...');
    try {
      const response = await fetch('/api/discover', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(collectOptions())
      });
      const data = await safeJson(response);
      if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);

      const queryBox = $('#queryBox');
      const queryText = $('#queryText');
      if (queryBox && queryText) {
        queryText.innerHTML = Array.isArray(data.queries)
          ? data.queries.map((query, index) => `${index + 1}. ${esc(query)}`).join('<br>')
          : 'Nenhuma consulta gerada.';
        queryBox.hidden = false;
        queryBox.style.display = 'block';
      }

      const stats = renderStats(data);
      if (!Array.isArray(data.results) || data.results.length === 0) {
        let html = `<b>Nenhuma loja foi confirmada com os critérios atuais.</b>${stats}` +
          `<p class="note">Isso é intencional: o detector prioriza precisão e pode retornar menos resultados do que o solicitado.</p>`;
        if (Array.isArray(data.rejectedSamples) && data.rejectedSamples.length) {
          html += `<div class="metric">Exemplos descartados:</div>`;
          html += data.rejectedSamples.map((item) =>
            `<div class="result"><b>${esc(item.title)}</b><br>` +
            `<a href="${esc(item.url)}" target="_blank" rel="noreferrer">${esc(item.url)}</a>` +
            `<div class="metric">${esc((item.rejectionReasons || []).join(' · '))}</div></div>`
          ).join('');
        }
        showOutput(html, 'warn');
        return;
      }

      let html = `<div class="row"><h2>Sites confirmados</h2><span class="chip good">${esc(data.results.length)} encontrados</span></div>` +
        stats +
        `<p class="note">Provedor: ${esc(data.provider)} · Os resultados passaram pela verificação passiva e pelos critérios selecionados.</p>`;
      html += data.results.map(renderResultCard).join('');
      if (Number(data.shortfall) > 0) {
        html += `<div class="card warn" style="margin-top:12px;margin-bottom:0"><b>${esc(data.shortfall)} resultado(s) não foram preenchidos.</b><div class="note">Não foram encontrados candidatos adicionais que passassem pelos critérios.</div></div>`;
      }
      showOutput(html, 'success');
    } catch (error) {
      showOutput(`<b>Erro na descoberta:</b> ${esc(error.message)}`, 'error');
    } finally {
      setBusy(button, false, 'Pesquisar e analisar automaticamente', 'Pesquisando e verificando...');
    }
  }

  function init() {
    fillSelect('#gateway', gateways);
    fillSelect('#niche', niches);
    fillSelect('#country', countries);

    $$('.tab').forEach((button) => {
      button.addEventListener('click', () => activatePanel(button.dataset.panel));
    });
    $('#goDiscover')?.addEventListener('click', () => activatePanel('discover'));
    $('#scanBtn')?.addEventListener('click', scanUrl);
    $('#queryBtn')?.addEventListener('click', showQueries);
    $('#testBtn')?.addEventListener('click', testProvider);
    $('#discoverBtn')?.addEventListener('click', discoverSites);

    $('#url')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') scanUrl();
    });
    $('#custom')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') discoverSites();
    });

    const hash = location.hash.replace(/^#/, '');
    activatePanel(['discover', 'scan', 'all'].includes(hash) ? hash : 'discover', false);
    const ready = $('#uiStatus');
    if (ready) ready.textContent = 'Interface carregada e filtros prontos.';
  }

  window.addEventListener('DOMContentLoaded', init, { once: true });
})();
