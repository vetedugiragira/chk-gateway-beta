const express = require('express');
const cors = require('cors');
const dns = require('dns').promises;
const net = require('net');
const path = require('path');
require('dotenv').config();

const app = express();
const APP_VERSION = '2.4.6';
const PORT = Number(process.env.PORT || 3000);
const SERPER_API_KEY = String(process.env.SERPER_API_KEY || '').trim().replace(/\s+/g, '');
const ALLOW_PRIVATE_TARGETS = String(process.env.ALLOW_PRIVATE_TARGETS || '').toLowerCase() === 'true';
const PUBLIC_DIR = path.join(__dirname, 'public');

app.use(cors());
app.use(express.json({ limit: '300kb' }));
app.use((req, res, next) => {
  if (req.path === '/' || req.path.endsWith('.html')) {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  }
  next();
});
app.use(express.static(PUBLIC_DIR, { etag: false, lastModified: false, maxAge: 0 }));

// Fingerprints: strong evidence is based on technical integration artifacts, not a provider name alone.
const GATEWAYS = {
  stripe: {
    label: 'Stripe', type: 'gateway',
    searchPhrases: ['Stripe Checkout ecommerce', 'Stripe JS loja pagamento', 'stripe.js checkout loja'],
    strong: [
      /js\.stripe\.com/i, /checkout\.stripe\.com/i, /api\.stripe\.com/i,
      /stripe\.js/i, /stripe-checkout/i, /stripe\.com\/v\d/i, /StripeCheckout/i
    ],
    medium: [/Stripe\s*\(/i, /StripeCheckout/i, /stripeElements/i, /elements\s*:\s*\{/i],
    weak: [/stripe/i]
  },
  asaas: {
    label: 'Asaas', type: 'gateway',
    searchPhrases: ['Asaas pagamento loja ecommerce', 'Asaas checkout ecommerce', 'payments asaas loja'],
    strong: [/asaas\.com/i, /payments\.asaas\.com/i, /api\.asaas\.com/i, /sandbox\.asaas\.com/i],
    medium: [/asaas/i], weak: [/asaas/i]
  },
  mercadopago: {
    label: 'Mercado Pago', type: 'gateway',
    searchPhrases: ['Mercado Pago checkout loja ecommerce', 'Mercado Pago pagamento loja online', 'Mercado Pago SDK checkout'],
    strong: [/mercadopago\.com/i, /mercadolibre\.com/i, /mpago\.li/i, /MercadoPago/i, /MercadoPagoCheckout/i],
    medium: [/mercado\s*pago/i], weak: [/mercado\s*pago/i]
  },
  pagbank: {
    label: 'PagBank/PagSeguro', type: 'gateway',
    searchPhrases: ['PagBank checkout loja ecommerce', 'PagSeguro checkout loja online', 'PagBank pagamento ecommerce'],
    strong: [/pagseguro\.com/i, /pagbank\.com/i, /pagseguro\.uol\.com\.br/i, /PagSeguroDirectPayment/i, /PagBankCheckout/i],
    medium: [/pagbank/i, /pagseguro/i], weak: [/pagbank/i, /pagseguro/i]
  },
  paypal: {
    label: 'PayPal', type: 'gateway',
    searchPhrases: ['PayPal checkout loja ecommerce', 'PayPal pagamento loja online', 'PayPal buttons ecommerce'],
    strong: [/paypal\.com/i, /paypalobjects\.com/i, /paypal\.Buttons/i, /paypal\..*client-id/i],
    medium: [/paypal/i], weak: [/paypal/i]
  },
  adyen: {
    label: 'Adyen', type: 'gateway',
    searchPhrases: ['Adyen checkout ecommerce loja', 'Adyen pagamento ecommerce', 'Adyen Checkout SDK loja'],
    strong: [/adyen\.com/i, /checkoutshopper-live\.adyen\.com/i, /checkoutshopper-test\.adyen\.com/i, /AdyenCheckout/i],
    medium: [/adyen/i], weak: [/adyen/i]
  },
  pagarme: {
    label: 'Pagar.me', type: 'gateway',
    searchPhrases: ['Pagar.me checkout loja ecommerce', 'Pagar.me pagamento loja online', 'PagarMe ecommerce checkout'],
    strong: [/pagar\.me/i, /api\.pagar\.me/i, /PagarMe/i, /pagarme/i],
    medium: [/pagar\s*\.?(me)/i, /pagarme/i], weak: [/pagarme/i]
  },
  iugu: {
    label: 'Iugu', type: 'gateway',
    searchPhrases: ['Iugu pagamento loja ecommerce', 'Iugu checkout ecommerce', 'Iugu loja online pagamento'],
    strong: [/iugu\.com/i, /api\.iugu\.com/i, /IuguCheckout/i], medium: [/iugu/i], weak: [/iugu/i]
  },
  ebanx: {
    label: 'EBANX', type: 'gateway',
    searchPhrases: ['EBANX pagamento loja ecommerce', 'EBANX checkout ecommerce', 'EBANX payment loja online'],
    strong: [/ebanx\.com/i, /api\.ebanx\.com/i, /Ebanx/i], medium: [/ebanx/i], weak: [/ebanx/i]
  },
  cielo: {
    label: 'Cielo', type: 'gateway',
    searchPhrases: ['Cielo ecommerce checkout loja', 'Cielo pagamento loja online', 'Cielo checkout ecommerce'],
    strong: [/cieloecommerce\.cielo\.com\.br/i, /cielo\.com\.br/i, /CieloEcommerce/i, /CieloCheckout/i],
    medium: [/cielo/i], weak: [/cielo/i]
  },
  getnet: {
    label: 'Getnet', type: 'gateway',
    searchPhrases: ['Getnet checkout loja ecommerce', 'Getnet pagamento ecommerce', 'Getnet loja online pagamento'],
    strong: [/getnet\.com\.br/i, /api\.getnet\.com\.br/i, /GetnetCheckout/i], medium: [/getnet/i], weak: [/getnet/i]
  },
  rede: {
    label: 'Rede', type: 'gateway',
    searchPhrases: ['userede ecommerce checkout loja', 'Rede Userede pagamento ecommerce', 'userede checkout loja online'],
    strong: [/userede\.com\.br/i, /api\.userede\.com\.br/i, /useredecloud\.com\.br/i, /redecard\.com\.br/i, /Userede/i],
    medium: [/userede/i], weak: []
  },
  // Nuuvem is a merchant/platform, not a generic payment gateway. Keep it for compatibility but never treat the word alone as gateway evidence.
  nuuvem: {
    label: 'Nuuvem (plataforma)', type: 'platform',
    searchPhrases: ['Nuuvem jogos pagamento loja online'],
    strong: [/nuuvem\.com/i], medium: [/nuuvem/i], weak: [/nuuvem/i]
  }
};

const NICHES = {
  qualquer: [],
  joias: ['joias', 'joalheria', 'anel', 'brinco', 'colar', 'pulseira', 'semijoias'],
  roupas: ['roupas', 'moda', 'vestuario', 'camiseta', 'calca', 'vestido'],
  calcados: ['calcados', 'sapatos', 'tenis', 'sandalia', 'bota'],
  eletronicos: ['eletronicos', 'eletronica', 'celular', 'smartphone', 'notebook', 'computador', 'gamer'],
  moveis: ['moveis', 'sofa', 'mesa', 'cadeira', 'decoracao', 'mobiliario'],
  beleza: ['beleza', 'cosmeticos', 'maquiagem', 'perfume', 'skincare', 'cabelo'],
  casa: ['casa', 'cozinha', 'utilidades', 'organizacao', 'eletrodomesticos'],
  esportes: ['esportes', 'fitness', 'academia', 'corrida', 'futebol', 'bike'],
  alimentos: ['alimentos', 'comida', 'doces', 'bebidas', 'mercearia', 'delivery'],
  livros: ['livros', 'livraria', 'literatura', 'ebook'],
  pet: ['pet', 'pets', 'cachorro', 'gato', 'racao', 'veterinaria']
};

const COUNTRY_MAP = {
  BR: { label: 'Brasil', gl: 'br', hl: 'pt-br', terms: ['Brasil'] },
  US: { label: 'Estados Unidos', gl: 'us', hl: 'en', terms: ['United States'] },
  PT: { label: 'Portugal', gl: 'pt-pt', hl: 'pt', terms: ['Portugal'] },
  MX: { label: 'México', gl: 'mx', hl: 'es', terms: ['Mexico'] },
  AR: { label: 'Argentina', gl: 'ar', hl: 'es', terms: ['Argentina'] },
  CO: { label: 'Colômbia', gl: 'co', hl: 'es', terms: ['Colombia'] },
  CL: { label: 'Chile', gl: 'cl', hl: 'es', terms: ['Chile'] }
};

const NON_STORE_HOSTS = new Set([
  'google.com', 'googleusercontent.com', 'wikipedia.org', 'youtube.com', 'youtu.be',
  'facebook.com', 'instagram.com', 'linkedin.com', 'tiktok.com', 'x.com', 'twitter.com',
  'reddit.com', 'github.com', 'stackoverflow.com', 'medium.com'
]);
const NON_STORE_PATH = /\/(docs?|documentation|developers?|developer|api|support|ajuda|help|blog|news|noticias|about|sobre|terms|termos|privacy|privacidade|status)(\/|$)/i;

function normalizeText(value) {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

function unique(arr) { return [...new Set(arr)]; }

function regexHits(corpus, patterns) {
  const evidence = [];
  for (const rx of patterns || []) if (rx.test(corpus)) evidence.push(rx.source.replace(/\\/g, ''));
  return unique(evidence);
}

function analyzeText(text, sourceUrl = '') {
  const corpus = String(text || '') + '\n' + String(sourceUrl || '');
  const lower = normalizeText(corpus);
  const gatewayResults = [];

  for (const [id, g] of Object.entries(GATEWAYS)) {
    const strong = regexHits(corpus, g.strong);
    const medium = regexHits(corpus, g.medium);
    const weak = regexHits(corpus, g.weak);
    let score = 0;
    if (strong.length) score = Math.min(99, 78 + Math.min(18, (strong.length - 1) * 8));
    else if (medium.length) score = Math.min(69, 52 + Math.min(14, (medium.length - 1) * 7));
    else if (weak.length && /(checkout|carrinho|cart|pagamento|payment|comprar|pedido|order|billing|pay)/i.test(corpus)) score = 28;
    else continue;

    // Never allow the generic word "rede" to produce a positive result.
    if (id === 'rede' && !strong.length && !medium.length) continue;
    gatewayResults.push({
      id, name: g.label, type: g.type, score,
      confidence: score >= 78 ? 'alta' : score >= 50 ? 'média' : 'baixa',
      evidence: [...strong.map(x => `forte:${x}`), ...medium.map(x => `média:${x}`)].slice(0, 10),
      weakMatches: weak.slice(0, 4)
    });
  }

  gatewayResults.sort((a, b) => b.score - a.score || b.evidence.length - a.evidence.length);
  const ecommercePatterns = [
    /checkout/i, /carrinho/i, /\bcart\b/i, /comprar/i, /finalizar\s*(a\s*)?compra/i,
    /pagamento/i, /payment/i, /pedido/i, /\border\b/i, /produto/i, /product/i,
    /\bshop\b/i, /loja/i, /ecommerce/i, /e-commerce/i, /preco|preço/i, /add-to-cart/i
  ];
  const ecommerceEvidence = regexHits(corpus, ecommercePatterns);
  const ecommerceScore = Math.min(99, ecommerceEvidence.length * 8);
  return { gateways: gatewayResults, ecommerceScore, ecommerceEvidence: ecommerceEvidence.slice(0, 14) };
}

function detectNiche(text, selectedNiche = 'qualquer') {
  const corpus = normalizeText(text);
  if (selectedNiche && selectedNiche !== 'qualquer') {
    const terms = NICHES[selectedNiche] || [];
    const evidence = terms.filter(t => corpus.includes(normalizeText(t)));
    const score = Math.min(99, evidence.length * 22);
    return { niche: selectedNiche, score, evidence: evidence.slice(0, 10) };
  }
  let best = { niche: 'qualquer', score: 0, evidence: [] };
  for (const [name, terms] of Object.entries(NICHES)) {
    if (name === 'qualquer') continue;
    const evidence = terms.filter(t => corpus.includes(normalizeText(t)));
    const score = Math.min(99, evidence.length * 22);
    if (score > best.score) best = { niche: name, score, evidence: evidence.slice(0, 10) };
  }
  return best;
}

function safeUrl(raw) {
  try {
    const url = new URL(String(raw).trim());
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    url.hash = '';
    return url;
  } catch { return null; }
}

function isPrivateIPv4(ip) {
  const parts = ip.split('.').map(Number);
  if (parts.length !== 4 || parts.some(n => Number.isNaN(n))) return false;
  const [a, b] = parts;
  return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
}
function isPrivateIPv6(ip) {
  const s = ip.toLowerCase();
  return s === '::1' || s.startsWith('fc') || s.startsWith('fd') || s.startsWith('fe80:');
}
function isPrivateIp(ip) { return net.isIP(ip) === 4 ? isPrivateIPv4(ip) : isPrivateIPv6(ip); }

async function hostAllowed(hostname) {
  if (ALLOW_PRIVATE_TARGETS) return { allowed: true, addresses: [] };
  try {
    const addresses = await dns.lookup(hostname, { all: true, verbatim: true });
    const blocked = addresses.some(a => isPrivateIp(a.address));
    return { allowed: !blocked, addresses: addresses.map(a => a.address) };
  } catch (error) { return { allowed: false, addresses: [], error: error.message }; }
}

async function fetchPublicPage(rawUrl) {
  const url = safeUrl(rawUrl);
  if (!url) return { ok: false, error: 'URL inválida ou protocolo não permitido.' };
  const guard = await hostAllowed(url.hostname);
  if (!guard.allowed) return { ok: false, error: guard.error || 'Destino bloqueado pela proteção de rede.' };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(url.href, {
      method: 'GET', redirect: 'manual', signal: controller.signal,
      headers: { 'User-Agent': 'GatewayDetector/2.4.3 (passive-public-web-research)', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.7' }
    });
    const contentType = response.headers.get('content-type') || '';
    const body = contentType.includes('text/html') || contentType.includes('application/xhtml+xml') ? await response.text() : '';
    return { ok: response.ok, status: response.status, finalUrl: url.href, contentType, content: body.slice(0, 900000) };
  } catch (error) {
    return { ok: false, error: error.name === 'AbortError' ? 'Timeout ao verificar o site.' : error.message };
  } finally { clearTimeout(timer); }
}

function cleanFreeQuery(value) {
  return String(value || '')
    .replace(/["'`()\[\]{}:|<>]/g, ' ')
    .replace(/\b(site|inurl|intitle|allintext|filetype):\S+/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function buildSearchQueries({ gateway, niche, country, custom }) {
  const c = COUNTRY_MAP[country] || COUNTRY_MAP.BR;
  const g = GATEWAYS[gateway];
  const nicheWords = niche && niche !== 'qualquer' ? (NICHES[niche] || []).slice(0, 2) : ['loja', 'ecommerce'];
  const nicheCore = nicheWords.join(' ');
  const countryTerm = c.terms[0] || c.label;
  const base = custom ? cleanFreeQuery(custom) : '';
  let phrases;
  if (g) {
    phrases = [...g.searchPhrases];
  } else {
    phrases = ['loja ecommerce pagamento online', 'loja online checkout pagamento', 'ecommerce loja comprar pagamento'];
  }
  const queries = phrases.map((p, i) => cleanFreeQuery(`${base} ${p} ${nicheCore} ${countryTerm}`));
  // No exact-match quotes or search operators: this is intentionally compatible with the free-safe Serper mode.
  return unique(queries.map(q => q.slice(0, 220))).slice(0, 3);
}

function searchDomainRoot(hostname) {
  const h = String(hostname || '').toLowerCase().replace(/^www\./, '');
  const parts = h.split('.');
  if (parts.length <= 2) return h;
  const commonSecondLevel = new Set(['com.br', 'com.mx', 'com.ar', 'com.co', 'com.cl', 'com.pt', 'co.uk', 'com.au']);
  const tail2 = parts.slice(-2).join('.');
  if (commonSecondLevel.has(tail2) && parts.length >= 3) return parts.slice(-3).join('.');
  return tail2;
}

function candidateLooksLikeStore(url, title = '') {
  const u = safeUrl(url);
  if (!u) return false;
  const host = u.hostname.toLowerCase();
  const root = searchDomainRoot(host);
  if (NON_STORE_HOSTS.has(root)) return false;
  if (NON_STORE_PATH.test(u.pathname)) return false;
  if (/\b(wikipedia|facebook|instagram|linkedin|youtube|tiktok|github|stackoverflow|documentation|docs|support)\b/i.test(title)) return false;
  // Provider's own corporate sites should not be returned as customer stores.
  for (const g of Object.values(GATEWAYS)) {
    for (const rx of g.strong || []) {
      const text = `${host}${u.pathname}`;
      if (rx.test(text) && /stripe|asaas|mercadopago|pagbank|pagseguro|paypal|adyen|pagar|iugu|ebanx|cielo|getnet|userede|nuuvem/i.test(host)) return false;
    }
  }
  return true;
}

function dedupeSearchResults(items) {
  const seen = new Set();
  const out = [];
  for (const item of items) {
    const u = safeUrl(item?.url);
    if (!u || !candidateLooksLikeStore(u.href, item.title)) continue;
    const root = searchDomainRoot(u.hostname);
    if (seen.has(root)) continue;
    seen.add(root);
    out.push({ ...item, url: u.href, domain: root });
  }
  return out;
}

function serperErrorMessage(status, data) {
  const msg = data?.message || data?.error || data?.errors?.[0]?.message || data?.statusMessage;
  if (status === 401 || status === 403) return 'Serper HTTP 403: a chave SERPER_API_KEY foi rejeitada pelo provedor.';
  if (status === 400) return `Serper HTTP 400: ${msg || 'requisição recusada pelo provedor. A versão 2.4.3 usa consultas simples sem operadores.'}`;
  if (status === 429) return 'Serper HTTP 429: limite de requisições atingido. Aguarde e tente novamente.';
  return msg ? `Serper HTTP ${status}: ${msg}` : `Serper HTTP ${status}`;
}

async function serperSearchOnce({ query, country, count }) {
  const c = COUNTRY_MAP[country] || COUNTRY_MAP.BR;
  const num = Math.max(1, Math.min(10, Number(count || 10)));
  const response = await fetch('https://google.serper.dev/search', {
    method: 'POST',
    headers: { 'X-API-KEY': SERPER_API_KEY, 'Content-Type': 'application/json', 'Accept': 'application/json' },
    body: JSON.stringify({ q: cleanFreeQuery(query), gl: c.gl, hl: c.hl, num, autocorrect: true })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(serperErrorMessage(response.status, data));
  return (data.organic || []).slice(0, num).map(item => ({ url: item.link, title: item.title || item.link, snippet: item.snippet || '', position: item.position || null }));
}

async function serperSearch({ queries, country, candidateLimit }) {
  if (!SERPER_API_KEY) throw new Error('SERPER_API_KEY não configurada. Configure o arquivo .env.');
  const limit = Math.max(10, Math.min(60, Number(candidateLimit || 30)));
  const all = [];
  for (const q of queries) {
    const remaining = limit - all.length;
    if (remaining <= 0) break;
    const batch = await serperSearchOnce({ query: q, country, count: Math.min(10, remaining) });
    all.push(...batch);
  }
  return dedupeSearchResults(all).slice(0, limit);
}

async function mapLimit(items, concurrency, worker) {
  const results = [];
  let next = 0;
  async function runner() {
    while (true) {
      const idx = next++;
      if (idx >= items.length) return;
      try { results[idx] = await worker(items[idx], idx); }
      catch (error) { results[idx] = { __error: error.message }; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, () => runner()));
  return results;
}

function buildResult(item, verification, options) {
  const text = `${item.title}\n${item.snippet}\n${verification.content || ''}`;
  const analysis = analyzeText(text, item.url);
  const nicheVerified = detectNiche(text, options.niche);
  const targetGateway = options.gateway && options.gateway !== 'qualquer' ? GATEWAYS[options.gateway] : null;
  const target = options.gateway !== 'qualquer';
  const detected = analysis.gateways[0];
  const gatewayScore = target ? (analysis.gateways.find(g => g.id === options.gateway)?.score || 0) : (detected?.score || 0);
  const commerce = analysis.ecommerceScore;
  const nicheScore = options.niche !== 'qualquer' ? nicheVerified.score : 55;
  const threshold = options.niche !== 'qualquer' ? 25 : 0;
  const acceptedGateway = target ? gatewayScore >= 55 : gatewayScore >= 55;
  const acceptedNiche = options.niche === 'qualquer' || nicheScore >= threshold;
  const acceptedCommerce = commerce >= 24;
  const accepted = verification.ok && acceptedGateway && acceptedNiche && acceptedCommerce;
  const totalScore = Math.min(99, Math.round(gatewayScore * 0.55 + nicheScore * 0.25 + commerce * 0.20));
  return {
    url: item.url,
    title: extractTitle(verification.content) || item.title,
    description: item.snippet || summarize(verification.content),
    detectedGateways: analysis.gateways,
    targetGateway: targetGateway?.label || 'Qualquer gateway',
    ecommerceScore: commerce,
    nicheVerified,
    totalScore,
    accepted,
    rejectionReasons: [
      !verification.ok ? `HTTP/GET não confirmado${verification.status ? ` (${verification.status})` : ''}` : null,
      !acceptedGateway ? (target ? `gateway alvo não confirmado (score ${gatewayScore})` : 'nenhuma evidência forte de gateway') : null,
      !acceptedNiche ? `nicho abaixo do mínimo (score ${nicheScore})` : null,
      !acceptedCommerce ? `sinais de e-commerce insuficientes (score ${commerce})` : null
    ].filter(Boolean),
    source: { provider: 'Serper/Google Search', position: item.position, domain: item.domain },
    verification: { ok: verification.ok, status: verification.status || null, error: verification.error || null }
  };
}

async function analyzeCandidates(candidates, options) {
  const verified = await mapLimit(candidates, 4, async item => {
    const verification = await fetchPublicPage(item.url);
    return buildResult(item, verification, options);
  });
  const valid = verified.filter(Boolean).filter(r => r.accepted).sort((a, b) => b.totalScore - a.totalScore);
  const rejected = verified.filter(Boolean).filter(r => !r.accepted).sort((a, b) => b.totalScore - a.totalScore);
  return { valid, rejected, analyzed: verified.length };
}

function extractTitle(html) {
  const m = String(html).match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return m ? m[1].replace(/\s+/g, ' ').trim().slice(0, 180) : '';
}
function stripTags(html) {
  return String(html).replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}
function summarize(html) { const text = stripTags(html); return text ? text.slice(0, 220) + (text.length > 220 ? '…' : '') : 'Sem conteúdo textual disponível.'; }

app.post('/api/scan', async (req, res) => {
  try {
    const verification = await fetchPublicPage(req.body?.url);
    if (!verification.ok && !verification.content) return res.status(400).json({ ok: false, error: verification.error || `HTTP ${verification.status || 500}` });
    const analysis = analyzeText(verification.content || '', req.body?.url || verification.finalUrl || '');
    res.json({ ok: true, url: verification.finalUrl || req.body?.url, status: verification.status, ...analysis });
  } catch (error) { res.status(500).json({ ok: false, error: error.message }); }
});

app.get('/api/provider-status', (req, res) => res.json({ ok: true, provider: 'Serper/Google Search', configured: Boolean(SERPER_API_KEY), version: APP_VERSION }));

app.post('/api/provider-test', async (req, res) => {
  try {
    if (!SERPER_API_KEY) return res.status(400).json({ ok: false, error: 'SERPER_API_KEY não configurada. Crie .env a partir de .env.example.' });
    const results = await serperSearchOnce({ query: 'loja ecommerce pagamento', country: 'BR', count: 1 });
    res.json({ ok: true, provider: 'Serper/Google Search', resultCount: results.length });
  } catch (error) { res.status(502).json({ ok: false, error: error.message }); }
});

app.get('/api/discover-query', (req, res) => {
  try {
    const queries = buildSearchQueries({ gateway: req.query.gateway || 'qualquer', niche: req.query.niche || 'qualquer', country: req.query.country || 'BR', custom: req.query.custom || '' });
    res.json({ ok: true, queries });
  } catch (error) { res.status(400).json({ ok: false, error: error.message }); }
});

app.post('/api/discover', async (req, res) => {
  try {
    const body = req.body || {};
    const options = {
      gateway: String(body.gateway || 'qualquer'),
      niche: String(body.niche || 'qualquer'),
      country: String(body.country || 'BR'),
      count: Math.max(1, Math.min(20, Number(body.count || 20))),
      custom: String(body.custom || '').trim()
    };
    const queries = buildSearchQueries(options);
    const candidateLimit = Math.min(60, Math.max(options.count * 3, 20));
    const candidates = await serperSearch({ queries, country: options.country, candidateLimit });
    const ranked = await analyzeCandidates(candidates, options);
    const results = ranked.valid.slice(0, options.count);
    res.json({
      ok: true, mode: 'automatic-high-precision', queries, requested: options.count,
      candidates: candidates.length, analyzed: ranked.analyzed,
      accepted: results.length, rejected: ranked.rejected.length,
      shortfall: Math.max(0, options.count - results.length),
      provider: 'Serper/Google Search', ...options, results,
      rejectedSamples: ranked.rejected.slice(0, 8).map(r => ({ url: r.url, title: r.title, totalScore: r.totalScore, rejectionReasons: r.rejectionReasons }))
    });
  } catch (error) { res.status(500).json({ ok: false, error: error.message }); }
});

app.post('/api/analyze-urls', async (req, res) => {
  try {
    const body = req.body || {};
    const options = { gateway: String(body.gateway || 'qualquer'), niche: String(body.niche || 'qualquer'), country: String(body.country || 'BR'), count: Math.max(1, Math.min(20, Number(body.count || 20))) };
    if (!Array.isArray(body.urls)) return res.status(400).json({ ok: false, error: 'Envie uma lista de URLs.' });
    const candidates = dedupeSearchResults(body.urls.slice(0, 20).map(url => ({ url, title: url, snippet: '' })));
    const ranked = await analyzeCandidates(candidates, options);
    res.json({ ok: true, mode: 'manual-high-precision', ...options, results: ranked.valid.slice(0, options.count), analyzed: ranked.analyzed, rejected: ranked.rejected.length });
  } catch (error) { res.status(500).json({ ok: false, error: error.message }); }
});

app.get('/api/health', (req, res) => res.json({ ok: true, version: APP_VERSION, discovery: Boolean(SERPER_API_KEY), provider: 'Serper/Google Search' }));
app.use((req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));
app.listen(PORT, () => console.log(`Gateway Detector ${APP_VERSION} rodando em http://localhost:${PORT}`));
