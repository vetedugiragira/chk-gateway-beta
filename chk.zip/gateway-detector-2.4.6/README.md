# Gateway Detector 2.4.6

Detector passivo para testes autorizados de presença de gateways e descoberta de sites públicos.

## Novidade da 2.4.6
- As áreas **Buscar sites** e **Analisar URL** ficaram separadas e acessíveis.
- A interface tem os modos `Buscar sites`, `Analisar URL` e `Mostrar tudo`.
- Gateway, nicho, país e quantidade de resultados ficam sempre disponíveis no painel de busca.
- Cache da interface desativado para evitar carregar uma tela antiga.

## Instalação
1. `npm install`
2. `copy .env.example .env`
3. Edite `.env` e coloque `SERPER_API_KEY=SUA_CHAVE`
4. `npm start`
5. Abra `http://localhost:3000`

O módulo de descoberta usa resultados públicos do Serper e depois verifica cada candidato com uma requisição GET passiva.

Não há login, transação, port scanning ou crawling recursivo.
